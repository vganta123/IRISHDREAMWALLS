// IRISHDREAMWALLS - script
document.getElementById('navToggle').addEventListener('click', function(){
  const nav = document.getElementById('mainNav');
  nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
});
document.getElementById('year').textContent = new Date().getFullYear();

// Gallery lightbox
const gallery = document.getElementById('galleryGrid');
const lightbox = document.getElementById('lightbox');
const lbImage = document.getElementById('lbImage');
const lbClose = document.getElementById('lbClose');

if(gallery){
  gallery.addEventListener('click', function(e){
    const img = e.target.closest('img');
    if(!img) return;
    const full = img.getAttribute('data-full');
    lbImage.src = full || img.src;
    lightbox.classList.add('visible');
    lightbox.setAttribute('aria-hidden','false');
  });
}

if(lbClose){
  lbClose.addEventListener('click', function(){ lightbox.classList.remove('visible'); lightbox.setAttribute('aria-hidden','true'); });
}
